#include<iostream>
#include<queue>
#include<vector>
using namespace std;

struct node
{
    int index;
    node* next = NULL;
};

node noUse[9999];   //用來給list空間
node* list[9999];   //adjacency-list
int color[9999];    //1代表白色，2代表灰色，3代表黑色
int pre_node[9999];     //紀錄BFS前個點
int dist[9999];         //紀錄BFS距離
int flow_path[9999];    //紀錄flow前個點
int flow_rest[9999][9999];      //紀錄邊的剩餘容量

void initial(int num){
    for(int i=1;i<num+1;i++){
        color[i] = 1;
        pre_node[i] = -1;
        dist[i] = -1;
        flow_path[i] = -1;
    }
}

void initial_flow(int num){
    for(int i=1;i<num+1;i++){
        for(int j=1;j<num+1;j++){
            flow_rest[i][j] = 1;
        }
    }
}

void add_edge(node* u, int v){
    node* tmp = new node();
    tmp->index = v;
    node* temp = u;
    while(temp->next){
        temp = temp->next;
    }
    temp->next = tmp;
}

//用來找bridge
int BFS_find(int u, int v, int nou, int nov){
    queue<int> travel;
    travel.push(u);
    dist[u] = 0;
    while(!travel.empty()){
        int from = travel.front();
        travel.pop();
        color[from] = 3;
        node* tmp = list[from];
        while(tmp->next){
            tmp = tmp->next;
            int to = tmp->index;
            if((from == nou && to == nov) || (from == nov && to == nou)){
                continue;
            }
            if(color[to] == 1 && flow_rest[from][to] > 0){    //白色才加入queue
                flow_path[to] = from;
                travel.push(to);
                color[to] = 2;    //變成灰色
                dist[to] = dist[from]+1;
                pre_node[to] = from;
                if(to == v){
                    int cur = v, pre = flow_path[cur];
                    while(pre != -1){
                        flow_rest[pre][cur] -= 1;
                        flow_rest[cur][pre] += 1;
                        cur = pre;
                        pre = flow_path[cur];
                    }
                    return 1;
                }
            }
        }
    }
    return 0;
}

//用來找bridge個數
int BFS(int u, int v){
    queue<int> travel;
    travel.push(u);
    dist[u] = 0;
    while(!travel.empty()){
        int from = travel.front();
        travel.pop();
        color[from] = 3;
        node* tmp = list[from];
        while(tmp->next){
            tmp = tmp->next;
            int to = tmp->index;
            if(color[to] == 1 && flow_rest[from][to] > 0){    //白色才加入queue
                flow_path[to] = from;
                travel.push(to);
                color[to] = 2;    //變成灰色
                dist[to] = dist[from]+1;
                pre_node[to] = from;
                if(to == v){
                    int cur = v, pre = flow_path[cur];
                    while(pre != -1){
                        flow_rest[pre][cur] -= 1;
                        flow_rest[cur][pre] += 1;
                        cur = pre;
                        pre = flow_path[cur];
                    }
                    return 1;
                }
            }
        }
    }
    return 0;
}

int main()
{
    //輸入並建立adjacency list
    int nodeNum, edgeNum;
    cin >> nodeNum >> edgeNum;
    initial(nodeNum);
    initial_flow(nodeNum);
    for(int i=0;i<nodeNum+1;i++){
        list[i] = &noUse[i];
    }
    for(int i=0;i<edgeNum;i++){
        int u, v;
        cin >> u >> v;
        add_edge(list[u], v);
        add_edge(list[v], u);
    }

    //找到mincut
    int min = 99999, min_u, min_v;
    for(int i=2;i<nodeNum+1;i++){
        int count = 0;
        int temp = 1;
        while(temp == 1){
            temp = BFS(1, i);
            initial(nodeNum);
            if(temp == 1)
                count++;
        }
        if(count < min){
            min = count;
            min_u = 1;
            min_v = i;
        }
        initial_flow(nodeNum);
    }

    //印出bridge個數
    cout << min << endl;

    //將flow的狀態變變成min_cut的樣子
    int temp_r = 1;
    while(temp_r == 1){
        temp_r = BFS(min_u, min_v);
        initial(nodeNum);
    }

    //將flow的狀態記錄下來，以用來求bridge
    int record[nodeNum+1][nodeNum+1];
    for(int i=1;i<nodeNum+1;i++){
        for(int j=1;j<nodeNum+1;j++){
            record[i][j] = flow_rest[i][j];
        }
    }
    initial_flow(nodeNum);

    //印出bridge
    int print_time = min;
    for(int i=1;i<nodeNum+1;i++){
        if(print_time == 0)
            break;
        for(int j=1;j<nodeNum+1;j++){
            if(record[i][j]<=0){
                int count = 0;
                int temp = 1;
                while(temp == 1){
                    temp = BFS_find(min_u, min_v, i, j);
                    initial(nodeNum);
                    if(temp == 1)
                        count++;
                }
                initial_flow(nodeNum);
                if(count < min){
                    cout << i << " " << j << endl;
                    print_time--;
                }
                if(print_time == 0)
                    break;
            }
        }
    }

}